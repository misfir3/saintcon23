# production settings/secrets go here
# this file is out-of-scope for vulnerabilities

# set to bcrypt standards for production server
BCRYPT_ROUNDS = 16
DEBUG = True