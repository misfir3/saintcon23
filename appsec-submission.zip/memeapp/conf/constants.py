# this file is out-of-scope for vulnerabilities
SESSION_TOKEN_NAME = "session"
DB_NAME = 'memes.db'
UPLOAD_DIR_NAME = 'user_uploads'
