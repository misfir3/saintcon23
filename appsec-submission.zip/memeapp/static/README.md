# Static

This directory contains some very basic static assets (javascript and CSS). Feel free to add to these files if you want.