# Templates

This directory contains templates, which are used by Flask to produce web pages.

See the [Flask Documentation](https://flask.palletsprojects.com/en/2.3.x/tutorial/templates/) and
the [Jinja documentation](https://jinja.palletsprojects.com/en/3.1.x/) for more information.