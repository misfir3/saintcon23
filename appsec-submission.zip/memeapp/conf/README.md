# Config

This is where application configuration is stored. This directory is out-of-scope for vulnerabilities, but you are
welcome to add to it if you like. Note that values in `config.py` are overriden by `local_config.py`. 